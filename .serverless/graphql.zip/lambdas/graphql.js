(()=>{var e={278:e=>{e.exports={Query:{hello:()=>"Hello world!"}}},703:(e,r,o)=>{const{gql:t}=o(270),l=t`
  type Query {
    hello: String
  }
`;e.exports=l},270:e=>{"use strict";e.exports=require("apollo-server-lambda")}},r={};function o(t){var l=r[t];if(void 0!==l)return l.exports;var s=r[t]={exports:{}};return e[t](s,s.exports,o),s.exports}var t={};(()=>{var e=t;const{ApolloServer:r}=o(270),l=new r({typeDefs:o(703),resolvers:o(278)});e.graphqlHandler=l.createHandler()})();var l=exports;for(var s in t)l[s]=t[s];t.__esModule&&Object.defineProperty(l,"__esModule",{value:!0})})();
//# sourceMappingURL=graphql.js.map