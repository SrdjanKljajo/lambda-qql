(()=>{var e={270:e=>{"use strict";e.exports=require("apollo-server-lambda")}},r={};function o(l){var t=r[l];if(void 0!==t)return t.exports;var a=r[l]={exports:{}};return e[l](a,a.exports,o),a.exports}var l={};(()=>{var e=l;const{ApolloServer:r,gql:t}=o(270),a=new r({typeDefs:t`
  type Query {
    hello: String
  }
`,resolvers:{Query:{hello:()=>"Hello world!"}}});e.graphqlHandler=a.createHandler()})();var t=exports;for(var a in l)t[a]=l[a];l.__esModule&&Object.defineProperty(t,"__esModule",{value:!0})})();
//# sourceMappingURL=graphql.js.map